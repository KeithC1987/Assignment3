﻿using Assignment3.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Tests
{
    public class LinkedListTests
    {
        private ILinkedListADT linkedList;

        [SetUp]
        public void Setup()
        {
            // Create your concrete linked list class and assign to linkedList.
            this.linkedList = new SLL();
        }

        [TearDown]
        public void TearDown()
        {
            this.linkedList.Clear();
        }

        // Test deleting a node from the end of the linked list.
        [Test]
        public void TestDeleteNodeFromEnd()
        {
            User user1 = new User(1, "A", "email", "password");
            User user2 = new User(2, "B", "email", "password");
            User user3 = new User(3, "C", "email", "password");

            this.linkedList.AddLast(user1);
            this.linkedList.AddLast(user2);
            this.linkedList.AddLast(user3);

            this.linkedList.Remove(this.linkedList.Count() - 1);

            /**
             * Linked list should now be:
             * 
             * user1 -> user2
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 2
            Assert.AreEqual(2, this.linkedList.Count());

            // Test the first node value is user1
            Assert.AreEqual(user1, this.linkedList.GetValue(0));

            // Test the second node value is user2
            Assert.AreEqual(user2, this.linkedList.GetValue(1));
        }

        // Test deleting a node from the middle of the linked list.
        [Test]
        public void TestDeleteNodeFromMiddle()
        {
            User user4 = new User(4, "D", "email", "password");
            User user5 = new User(5, "E", "email", "password");
            User user6 = new User(6, "F", "email", "password");

            this.linkedList.AddLast(user4);
            this.linkedList.AddLast(user5);
            this.linkedList.AddLast(user6);

            this.linkedList.Remove(1); // Removing user5

            /**
             * Linked list should now be:
             * 
             * user4 -> user6
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 2
            Assert.AreEqual(2, this.linkedList.Count());

            // Test the first node value is user4
            Assert.AreEqual(user4, this.linkedList.GetValue(0));

            // Test the second node value is user6
            Assert.AreEqual(user6, this.linkedList.GetValue(1));
        }

        // Test finding and retrieving an existing node in the linked list.
        [Test]
        public void TestFindAndRetrieveExistingNode()
        {
            User user7 = new User(7, "G", "email", "password");
            User user8 = new User(8, "H", "email", "password");
            User user9 = new User(9, "I", "email", "password");

            this.linkedList.AddLast(user7);
            this.linkedList.AddLast(user8);
            this.linkedList.AddLast(user9);

            /**
             * Linked list should now be:
             * 
             * user7 -> user8 -> user9
             */

            bool contains = this.linkedList.Contains(user8);
            Assert.True(contains);

            int index = this.linkedList.IndexOf(user8);
            Assert.AreEqual(1, index);

            User retrievedUser = (User)this.linkedList.GetValue(1);
            Assert.AreEqual(user8, retrievedUser);
        }
    }
}